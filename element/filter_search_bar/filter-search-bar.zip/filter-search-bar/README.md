# Filter/Search Bar

A Pen created on CodePen.io. Original URL: [https://codepen.io/geoffbuell/pen/PobXvyJ](https://codepen.io/geoffbuell/pen/PobXvyJ).

